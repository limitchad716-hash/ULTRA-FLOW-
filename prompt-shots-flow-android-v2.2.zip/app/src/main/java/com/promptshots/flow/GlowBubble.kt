package com.promptshots.flow

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.min

/**
 * The floating FLOW bubble: a filled circle with a slowly rotating rainbow ring and soft glow.
 * The view is bigger than the visible circle so the glow has room to fade out.
 */
class GlowBubble(c: Context) : View(c) {
    var label: String = "FLOW"
        set(v) { if (field != v) { field = v; invalidate() } }
    var fill: Int = Ui.ACCENT
        set(v) { if (field != v) { field = v; invalidate() } }
    var textSp: Float = 11f
        set(v) { if (field != v) { field = v; invalidate() } }
    var glow: Boolean = true
        set(v) {
            field = v
            if (isAttachedToWindow) { if (v) startSpin() else stopSpin() }
            invalidate()
        }

    private val pad = Ui.dp(c, 10).toFloat()
    private val rainbow = intArrayOf(
        0xFFFF3B3B.toInt(), 0xFFFF9800.toInt(), 0xFFFFEB3B.toInt(), 0xFF3DDC84.toInt(),
        0xFF29C5F6.toInt(), 0xFF5C6BFF.toInt(), 0xFFD84BFF.toInt(), 0xFFFF3B3B.toInt()
    )
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = Ui.dp(c, 3).toFloat()
    }
    // Soft glow = a few wide, faint strokes (no blur filter, so it stays on the GPU path).
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val glowWidths = floatArrayOf(Ui.dp(c, 4).toFloat(), Ui.dp(c, 8).toFloat(), Ui.dp(c, 12).toFloat(), Ui.dp(c, 16).toFloat())
    private val glowAlphas = intArrayOf(120, 70, 38, 16)
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER; color = Ui.ON_ACCENT
    }
    private var angle = 0f
    private var spin: ValueAnimator? = null

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val sg = SweepGradient(w / 2f, h / 2f, rainbow, null)
        ringPaint.shader = sg
        glowPaint.shader = sg
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (glow) startSpin()
    }

    override fun onDetachedFromWindow() {
        stopSpin()
        super.onDetachedFromWindow()
    }

    private fun startSpin() {
        if (spin != null) return
        spin = ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 3000
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { angle = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    private fun stopSpin() {
        spin?.cancel()
        spin = null
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f - pad
        if (glow) {
            canvas.save()
            canvas.rotate(angle, cx, cy)
            for (i in glowWidths.indices) {
                glowPaint.strokeWidth = glowWidths[i]
                glowPaint.alpha = glowAlphas[i]
                canvas.drawCircle(cx, cy, r, glowPaint)
            }
            canvas.restore()
        }
        fillPaint.color = fill
        canvas.drawCircle(cx, cy, r, fillPaint)
        if (glow) {
            canvas.save()
            canvas.rotate(angle, cx, cy)
            canvas.drawCircle(cx, cy, r - ringPaint.strokeWidth / 2f, ringPaint)
            canvas.restore()
        }
        textPaint.textSize = textSp * resources.displayMetrics.scaledDensity
        val fm = textPaint.fontMetrics
        canvas.drawText(label, cx, cy - (fm.ascent + fm.descent) / 2f, textPaint)
    }
}
