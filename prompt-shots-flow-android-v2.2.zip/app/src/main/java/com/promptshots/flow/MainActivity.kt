package com.promptshots.flow

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("flow", Context.MODE_PRIVATE)
    fun delay(c: Context) = sp(c).getInt("delay", 60)
    fun setDelay(c: Context, v: Int) = sp(c).edit().putInt("delay", v).apply()
    // The image list keeps the old "prompts" key so saved prompts survive the update.
    private fun key(k: PromptKind) = if (k == PromptKind.VIDEO) "prompts_video" else "prompts"
    fun prompts(c: Context, k: PromptKind = PromptKind.IMAGE) = sp(c).getString(key(k), "") ?: ""
    fun setPrompts(c: Context, v: String, k: PromptKind = PromptKind.IMAGE) = sp(c).edit().putString(key(k), v).apply()
    fun flag(c: Context, k: String, def: Boolean) = sp(c).getBoolean(k, def)
    fun setFlag(c: Context, k: String, v: Boolean) = sp(c).edit().putBoolean(k, v).apply()

    // Custom "automation finished" sound: the file is copied into the app's own storage.
    fun soundFile(c: Context) = File(c.filesDir, "notif_sound")
    fun soundName(c: Context): String? = sp(c).getString("sound_name", null)
    fun hasCustomSound(c: Context) = soundName(c) != null && soundFile(c).exists()
    fun setSound(c: Context, name: String) = sp(c).edit().putString("sound_name", name).apply()
    fun clearSound(c: Context) {
        sp(c).edit().remove("sound_name").apply()
        soundFile(c).delete()
    }
}

class MainActivity : Activity() {
    private lateinit var floatBtn: RainbowButton
    private val ui = Handler(Looper.getMainLooper())

    // Notification-sound picker state
    private var pendingUri: Uri? = null
    private var pendingName: String? = null
    private var soundInfo: TextView? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG

        floatBtn = RainbowButton(this, "Float") { toggleFloating() }
        val settingsBtn = RainbowButton(this, "Settings") { showSettings() }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Ui.BG)
            setPadding(Ui.dp(this@MainActivity, 24), 0, Ui.dp(this@MainActivity, 24), 0)
        }
        val h = Ui.dp(this, 110)
        root.addView(floatBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h))
        root.addView(settingsBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h)
            .apply { topMargin = Ui.dp(this@MainActivity, 8) })
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        Notifier.stop()
        super.onDestroy()
    }

    private fun hasOverlay() = Settings.canDrawOverlays(this)
    private fun hasNotif() = Build.VERSION.SDK_INT < 33 ||
        checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    private fun hasAcc() = FlowAccessibilityService.instance != null

    private fun refreshStatus() {
        floatBtn.text = if (FloatingService.alive) "Stop float" else "Float"
        floatBtn.setDanger(FloatingService.alive)
    }

    private fun toggleFloating() {
        if (FloatingService.alive) {
            stopService(Intent(this, FloatingService::class.java))
        } else {
            startFloating()
        }
        // The service flips its flag a moment after start/stop.
        ui.postDelayed({ refreshStatus() }, 400)
    }

    private fun startFloating() {
        if (!hasOverlay()) { toast("Allow 'Display over other apps' first"); openOverlaySettings(); return }
        if (!hasNotif()) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        val i = Intent(this, FloatingService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        if (!hasAcc()) toast("Tip: turn on Accessibility in Settings so Run can paste for you")
    }

    private fun openOverlaySettings() =
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))

    private fun openNotifSettings() {
        if (Build.VERSION.SDK_INT >= 33 && !hasNotif()) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        } else {
            startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        refreshStatus()
    }

    // ── Settings ───────────────────────────────────────────────────────────

    private fun showSettings() {
        fun mark(ok: Boolean) = if (ok) "✓  " else "✕  "
        val items = arrayOf(
            mark(hasOverlay()) + "Floating window permission",
            mark(hasAcc()) + "Accessibility (auto paste & run)",
            mark(hasNotif()) + "Notifications",
            "     Notification sound: ${Prefs.soundName(this) ?: "Default"}",
            "     Allow restricted settings (App info)",
            "     Battery: do not restrict",
            "     Wait between prompts: ${Prefs.delay(this)} s"
        )
        AlertDialog.Builder(this).setTitle("Settings").setItems(items) { _, w ->
            when (w) {
                0 -> openOverlaySettings()
                1 -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                2 -> openNotifSettings()
                3 -> showSoundDialog()
                4 -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
                5 -> startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                6 -> askDelay()
            }
        }.show()
    }

    private fun askDelay() {
        val e = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(Prefs.delay(this@MainActivity).toString())
            setSelection(text.length)
        }
        AlertDialog.Builder(this).setTitle("Seconds to wait between prompts (5–3600)").setView(e)
            .setPositiveButton("Save") { _, _ ->
                val v = e.text.toString().toIntOrNull() ?: 60
                Prefs.setDelay(this, v.coerceIn(5, 3600))
                toast("Saved: ${Prefs.delay(this)} s")
            }.setNegativeButton("Cancel", null).show()
    }

    // ── Custom notification sound: Upload → (Play) → Save ──────────────────

    private fun showSoundDialog() {
        pendingUri = null; pendingName = null
        val p = Ui.dp(this, 16)
        val info = TextView(this).apply { textSize = 15f }
        soundInfo = info
        updateSoundInfo()

        val upload = Ui.button(this, "Upload sound", Ui.Kind.SECONDARY) { pickSound() }
        val play = Ui.button(this, "Play", Ui.Kind.SECONDARY) { previewSound() }
        val save = Ui.button(this, "Save", Ui.Kind.PRIMARY) { saveSound() }
        val reset = Ui.button(this, "Use default sound", Ui.Kind.DANGER) {
            Notifier.stop()
            Prefs.clearSound(this)
            pendingUri = null; pendingName = null
            updateSoundInfo()
            toast("Back to the default sound")
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(p, p, p, 0)
            addView(info)
            addView(Ui.row(this@MainActivity, upload, play), LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = p })
            addView(Ui.row(this@MainActivity, save, reset))
        }
        AlertDialog.Builder(this).setTitle("Notification sound").setView(box)
            .setNegativeButton("Close") { _, _ -> Notifier.stop() }
            .setOnDismissListener { Notifier.stop(); soundInfo = null }
            .show()
    }

    private fun updateSoundInfo() {
        soundInfo?.text = if (pendingName != null)
            "Selected: $pendingName\nTap Save to use it."
        else
            "Current: ${Prefs.soundName(this) ?: "Default"}"
    }

    private fun pickSound() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/*"
        }
        try { startActivityForResult(i, REQ_SOUND) } catch (_: Exception) { toast("No file picker found") }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req != REQ_SOUND || res != RESULT_OK) return
        val uri = data?.data ?: return
        pendingUri = uri
        pendingName = try {
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                val col = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (c.moveToFirst() && col >= 0) c.getString(col) else null
            }
        } catch (_: Exception) { null } ?: "Selected sound"
        updateSoundInfo()
    }

    private fun previewSound() {
        val u = pendingUri
            ?: if (Prefs.hasCustomSound(this)) Uri.fromFile(Prefs.soundFile(this)) else null
        if (u == null) { toast("Upload a sound first"); return }
        Notifier.play(this, u)
    }

    private fun saveSound() {
        val u = pendingUri
        if (u == null) { toast("Upload a sound first"); return }
        try {
            val tmp = File(filesDir, "notif_sound.tmp")
            contentResolver.openInputStream(u)!!.use { input -> tmp.outputStream().use { input.copyTo(it) } }
            val dest = Prefs.soundFile(this)
            dest.delete()
            if (!tmp.renameTo(dest)) throw IllegalStateException("rename failed")
            Prefs.setSound(this, pendingName ?: "Custom sound")
            pendingUri = null; pendingName = null
            updateSoundInfo()
            toast("Saved. This sound plays when automation finishes.")
        } catch (_: Exception) {
            toast("Couldn't save that file. Try another sound.")
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    companion object { private const val REQ_SOUND = 41 }
}
