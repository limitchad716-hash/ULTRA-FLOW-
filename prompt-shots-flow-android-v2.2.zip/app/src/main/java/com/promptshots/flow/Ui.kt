package com.promptshots.flow

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import kotlin.math.min

/** Small shared look-and-feel helpers so the app and the floating window match. */
object Ui {
    val BG = 0xFF12151C.toInt()
    val SURFACE = 0xFF1D2330.toInt()
    val SURFACE_HI = 0xFF283044.toInt()
    val ACCENT = 0xFFE8A317.toInt()
    val ON_ACCENT = 0xFF2A1C00.toInt()
    val TEXT = 0xFFE9EDF3.toInt()
    val MUTED = 0xFF9AA4B5.toInt()
    val OK = 0xFF3DDC84.toInt()
    val OK_BG = 0xFF17301F.toInt()
    val BAD = 0xFFFF7B7B.toInt()
    val BAD_BG = 0xFF3A1B1F.toInt()

    enum class Kind { PRIMARY, SECONDARY, DANGER }

    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    fun rounded(color: Int, radius: Float) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
    }

    private fun lighten(c: Int, amt: Int = 30) = Color.argb(
        Color.alpha(c),
        min(255, Color.red(c) + amt),
        min(255, Color.green(c) + amt),
        min(255, Color.blue(c) + amt)
    )

    /** Round (oval) background with a lighter pressed state, for the circle option buttons. */
    fun circleBg(color: Int) = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_pressed), GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(lighten(color)) })
        addState(intArrayOf(), GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) })
    }

    /** Applies colours for a button kind (also used to flip Run all <-> Stop). */
    fun style(b: Button, kind: Kind) {
        val (bg, fg) = when (kind) {
            Kind.PRIMARY -> ACCENT to ON_ACCENT
            Kind.SECONDARY -> SURFACE_HI to TEXT
            Kind.DANGER -> BAD_BG to BAD
        }
        val r = dp(b.context, 10).toFloat()
        b.setTextColor(fg)
        b.background = StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), rounded(lighten(bg), r))
            addState(intArrayOf(), rounded(bg, r))
        }
    }

    fun button(c: Context, label: String, kind: Kind, onClick: () -> Unit): Button =
        Button(c).apply {
            text = label
            textSize = 13f
            isAllCaps = false
            minHeight = 0; minimumHeight = 0
            minWidth = 0; minimumWidth = 0
            stateListAnimator = null
            setPadding(dp(c, 10), dp(c, 10), dp(c, 10), dp(c, 10))
            style(this, kind)
            setOnClickListener { onClick() }
        }

    /** Equal-width row with a small gap between the children. */
    fun row(c: Context, vararg v: View): LinearLayout {
        val r = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        val m = dp(c, 3)
        v.forEach {
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(m, m, m, m)
            r.addView(it, lp)
        }
        return r
    }
}
