package com.promptshots.flow

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.view.Gravity
import android.view.animation.LinearInterpolator
import android.widget.TextView

/** Big button with a rotating rainbow edge and a soft rainbow glow around it. */
class RainbowButton(c: Context, label: String, onTap: () -> Unit) : TextView(c) {
    private val colors = intArrayOf(
        0xFFFF3B3B.toInt(), 0xFFFF9800.toInt(), 0xFFFFEB3B.toInt(), 0xFF3DDC84.toInt(),
        0xFF29C5F6.toInt(), 0xFF5C6BFF.toInt(), 0xFFD84BFF.toInt(), 0xFFFF3B3B.toInt()
    )
    private val inset = Ui.dp(c, 12).toFloat()
    private val radius = Ui.dp(c, 20).toFloat()
    private val stroke = Ui.dp(c, 3).toFloat()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Ui.SURFACE }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = stroke }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = stroke * 2.5f
        maskFilter = BlurMaskFilter(Ui.dp(c, 8).toFloat(), BlurMaskFilter.Blur.NORMAL)
    }
    private val rect = RectF()
    private val matrix = Matrix()
    private var shader: SweepGradient? = null
    private var angle = 0f
    private var anim: ValueAnimator? = null

    init {
        text = label
        gravity = Gravity.CENTER
        textSize = 22f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(Ui.TEXT)
        isClickable = true
        setLayerType(LAYER_TYPE_SOFTWARE, null) // needed for the blur glow
        setOnClickListener { onTap() }
    }

    fun setDanger(on: Boolean) = setTextColor(if (on) Ui.BAD else Ui.TEXT)

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        shader = SweepGradient(w / 2f, h / 2f, colors, null)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (anim == null) {
            anim = ValueAnimator.ofFloat(0f, 360f).apply {
                duration = 4000
                repeatCount = ValueAnimator.INFINITE
                interpolator = LinearInterpolator()
                addUpdateListener { angle = it.animatedValue as Float; invalidate() }
                start()
            }
        }
    }

    override fun onDetachedFromWindow() {
        anim?.cancel(); anim = null
        super.onDetachedFromWindow()
    }

    override fun drawableStateChanged() {
        super.drawableStateChanged()
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        shader?.let {
            matrix.setRotate(angle, width / 2f, height / 2f)
            it.setLocalMatrix(matrix)
            ring.shader = it
            glow.shader = it
        }
        rect.set(inset, inset, width - inset, height - inset)
        fill.color = if (isPressed) Ui.SURFACE_HI else Ui.SURFACE
        canvas.drawRoundRect(rect, radius, radius, glow)
        canvas.drawRoundRect(rect, radius, radius, fill)
        canvas.drawRoundRect(rect, radius, radius, ring)
        super.onDraw(canvas)
    }
}
